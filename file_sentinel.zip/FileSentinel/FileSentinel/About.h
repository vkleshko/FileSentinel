#pragma once
namespace About {
	using namespace System;
	using namespace System::Windows::Forms;
	public ref class About : public Form
	{
	public:
		About()
		{
			InitializeComponent();
			String^ exePath = Application::StartupPath;
			// ������� ���� �� ������ (��'� ����� ������ �� �������)
			String^ iconPath = System::IO::Path::Combine(exePath, "Logo.png");
			// ����������, �� ���� ����
			if (System::IO::File::Exists(iconPath)) {
				this->pictureBox1->Image = System::Drawing::Image::FromFile(iconPath);
			}
			else {
				MessageBox::Show("���� ������ �� ��������: " + iconPath, "�������", MessageBoxButtons::OK, MessageBoxIcon::Error);
			}
		}
	protected:
		~About()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::PictureBox^ pictureBox1;
	private: System::Windows::Forms::Label^ labelName;
	private: System::Windows::Forms::Label^ labelAuthor;
	private: System::Windows::Forms::Label^ labelGroup;
	private: System::Windows::Forms::Label^ labelTopic;
	private: System::Windows::Forms::Label^ labelVersion;
	protected:
	private:
		System::ComponentModel::Container^ components;
		void InitializeComponent(void)
		{
			System::ComponentModel::ComponentResourceManager^ resources = (gcnew System::ComponentModel::ComponentResourceManager(About::typeid));
			this->pictureBox1 = (gcnew System::Windows::Forms::PictureBox());
			this->labelName = (gcnew System::Windows::Forms::Label());
			this->labelAuthor = (gcnew System::Windows::Forms::Label());
			this->labelGroup = (gcnew System::Windows::Forms::Label());
			this->labelTopic = (gcnew System::Windows::Forms::Label());
			this->labelVersion = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->BeginInit();
			this->SuspendLayout();
			// 
			// pictureBox1
			// 
			this->pictureBox1->BackgroundImageLayout = System::Windows::Forms::ImageLayout::Zoom;
			this->pictureBox1->Location = System::Drawing::Point(136, 15);
			this->pictureBox1->Name = L"pictureBox1";
			this->pictureBox1->Size = System::Drawing::Size(128, 128); // ����� ���������� 128x128
			this->pictureBox1->TabIndex = 0;
			this->pictureBox1->TabStop = false;
			this->pictureBox1->SizeMode = System::Windows::Forms::PictureBoxSizeMode::Zoom;
			// 
			// labelName
			// 
			this->labelName->AutoSize = true;
			this->labelName->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12, System::Drawing::FontStyle::Bold, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->labelName->ForeColor = System::Drawing::Color::White;
			this->labelName->Location = System::Drawing::Point(20, 155);
			this->labelName->Name = L"labelName";
			this->labelName->Size = System::Drawing::Size(157, 21);
			this->labelName->TabIndex = 1;
			this->labelName->Text = L"�����: FileSentinel";
			// 
			// labelAuthor
			// 
			this->labelAuthor->AutoSize = true;
			this->labelAuthor->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->labelAuthor->ForeColor = System::Drawing::Color::White;
			this->labelAuthor->Location = System::Drawing::Point(20, 185);
			this->labelAuthor->Name = L"labelAuthor";
			this->labelAuthor->Size = System::Drawing::Size(313, 21);
			this->labelAuthor->TabIndex = 2;
			this->labelAuthor->Text = L"�����: ������ ��������� �������������";
			// 
			// labelGroup
			// 
			this->labelGroup->AutoSize = true;
			this->labelGroup->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->labelGroup->ForeColor = System::Drawing::Color::White;
			this->labelGroup->Location = System::Drawing::Point(20, 215);
			this->labelGroup->Name = L"labelGroup";
			this->labelGroup->Size = System::Drawing::Size(119, 21);
			this->labelGroup->TabIndex = 3;
			this->labelGroup->Text = L"�����: 2ϲ-22�";
			// 
			// labelTopic
			// 
			this->labelTopic->AutoSize = true;
			this->labelTopic->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->labelTopic->ForeColor = System::Drawing::Color::White;
			this->labelTopic->Location = System::Drawing::Point(20, 245);
			this->labelTopic->MaximumSize = System::Drawing::Size(360, 0);
			this->labelTopic->Name = L"labelTopic";
			this->labelTopic->Size = System::Drawing::Size(354, 42);
			this->labelTopic->TabIndex = 4;
			this->labelTopic->Text = L"����: �������� ����������� ���������� ��� ���������� ��� � ������";
			// 
			// labelVersion
			// 
			this->labelVersion->AutoSize = true;
			this->labelVersion->Font = (gcnew System::Drawing::Font(L"Segoe UI", 12, System::Drawing::FontStyle::Regular, System::Drawing::GraphicsUnit::Point,
				static_cast<System::Byte>(204)));
			this->labelVersion->ForeColor = System::Drawing::Color::White;
			this->labelVersion->Location = System::Drawing::Point(20, 295);
			this->labelVersion->Name = L"labelVersion";
			this->labelVersion->Size = System::Drawing::Size(84, 21);
			this->labelVersion->TabIndex = 5;
			this->labelVersion->Text = L"�����: 1.0";
			// 
			// About
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->BackColor = System::Drawing::Color::SteelBlue;
			this->ClientSize = System::Drawing::Size(400, 330);
			this->Controls->Add(this->labelVersion);
			this->Controls->Add(this->labelTopic);
			this->Controls->Add(this->labelGroup);
			this->Controls->Add(this->labelAuthor);
			this->Controls->Add(this->labelName);
			this->Controls->Add(this->pictureBox1);
			this->FormBorderStyle = System::Windows::Forms::FormBorderStyle::FixedDialog;
			this->MaximizeBox = false;
			this->MinimizeBox = false;
			this->Name = L"About";
			this->StartPosition = System::Windows::Forms::FormStartPosition::CenterParent;
			this->Text = L"��� ��������";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->pictureBox1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();
		}
	};
}