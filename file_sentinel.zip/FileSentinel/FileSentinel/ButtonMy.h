#pragma once
#include <msclr/marshal_cppstd.h>

using namespace System;
using namespace System::ComponentModel;
using namespace System::Collections;
using namespace System::Collections::Generic;
using namespace System::Windows::Forms;
using namespace System::Data;
using namespace System::Drawing;
using namespace System::IO;

// ��������� ����� ����, ���� ������ ListView
public ref class ButtonMy : public ToolStripButton
{
private:

public:
	System::Windows::Forms::ToolStripStatusLabel^ toolStripStatusLabel1;

	System::Windows::Forms::ListView^ listViewLog;
	ButtonMy(ListView^ listViewLog, ToolStripStatusLabel^ toolStripStatusLabel1)
	{

		this->toolStripStatusLabel1 = toolStripStatusLabel1;
		this->listViewLog = listViewLog;
		this->Click += gcnew System::EventHandler(this, &ButtonMy::ToolStripMenuItem_Click);
	}
	System::Void ToolStripMenuItem_Click(System::Object^ sender, System::EventArgs^ e) {
		listViewLog->Items->Clear();
		toolStripStatusLabel1->Text = "������ �������";
	}

};
